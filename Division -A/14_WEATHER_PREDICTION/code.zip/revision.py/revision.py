a = int(input("1.ADDITION/n2.SUBTRACTION/n3.MULTIPLICATION/n4.DIVISION"))
for i in range(1,5):
    if a==1:
        b = int(input("ENTER FIRST NUMBER"))
        c= int(input("ENTER Second NUMBER"))
        print("THE SOLUTION IS: ",b+c)
    elif a==2:
        b = int(input("ENTER FIRST NUMBER"))
        c= int(input("ENTER Second NUMBER"))
        print("THE SOLUTION IS: ",b-c)
    elif a==3:
        b = int(input("ENTER FIRST NUMBER"))
        c= int(input("ENTER Second NUMBER"))
        print("THE SOLUTION IS: ",b*c)
    elif a==4:
        b = int(input("ENTER FIRST NUMBER"))
        c= int(input("ENTER Second NUMBER"))
        print("THE SOLUTION IS: ",b/c)