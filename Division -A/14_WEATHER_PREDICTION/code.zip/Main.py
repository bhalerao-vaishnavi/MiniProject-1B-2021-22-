import json
import smtplib
import sys
import threading
import time
from types import CoroutineType
from PyQt5 import QtWidgets
from PyQt5 import QtCore
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi

from smtp import message

from geopy.geocoders import Nominatim
import requests
from timezonefinder import TimezoneFinder
from datetime import datetime
import pytz

import allimgs


class Mainwindow(QMainWindow):

    def __init__(self):
        super(Mainwindow,self).__init__()
        loadUi("Mainwindow.ui",self)
        self.setWindowTitle('Weather Forecast')
        self.sub.clicked.connect(self.submi)
        self.forecast.clicked.connect(self.forecas)
        self.clk.clicked.connect(self.clock)

    def forecas(self):
        w2.show()
        welcome.close()

    def clock(self):
        ""

    def submi(self):
        
        nm = self.name_line.text()
        ab = self.email_line.text()
        
        if len(nm)==0 or len(ab)==0:
            err = QMessageBox()
            err.setIcon(QMessageBox.Critical)
            err.setText("ERROR!! Empty Fields Detected") 
            err.setWindowTitle("Warning")
            err.setStandardButtons(QMessageBox.Ok)
            retval = err.exec_()
        else:
            
            try:
                ip = requests.get('https://api.ipify.org').text
                ip_address = ip
                request_url = 'https://geolocation-db.com/jsonp/' + ip_address
                response = requests.get(request_url)
                result = response.content.decode()
                # Clean the returned string so it just contains the dictionary data for the IP address
                result = result.split("(")[1].strip(")")
                # Convert this data into a dictionary
                result  = json.loads(result)
                city = result['city']
                # print(result['city'])

                geolocator = Nominatim(user_agent="geoapiExercises")
                location = geolocator.geocode(city)
                obj = TimezoneFinder()
                result = obj.timezone_at(lng=location.longitude, lat=location.latitude)
                home = pytz.timezone(result)
                local_time = datetime.now(home)
                current_time = local_time.strftime("%I:%M %p")

                # Weather API
                api = (
                "https://api.openweathermap.org/data/2.5/onecall?lat=38.7267&lon=-9.1403&exclude=current,hourly,minutely,alerts&units=metric&appid=a0436779bfc4457741c32fb931a75148"
                )
                json_data = requests.get(api).json()

                temperature = []
                feels_likeArray = []
                descripArray = []
                json_data = json_data["daily"]

                for i in range(7):
                    temperature.append(json_data[i]["temp"]["day"])
                    feels_likeArray.append(json_data[i]["weather"][0]["main"])
                    descripArray.append(json_data[i]["weather"][0]["description"])
                
                OutputString = ""
                
                for i in range(7):
                    OutputString += """\n Temperature for day """  + str(i ) + """ """ + str(temperature[i])
                    OutputString +=  """ \n Feels Like,  """  + str(feels_likeArray[i])
                    OutputString +=  """ \n So there will be """  + str(descripArray[i]) + """ \n"""

                server = smtplib.SMTP_SSL("smtp.gmail.com",465)
                server.login("youremail","password")
                SUBJECT = "WEATHER FORECAST"
                TEXT = "Hii "+nm+OutputString
                message = 'Subject: {}\n\n{}'.format(SUBJECT,TEXT)
                server.sendmail("youremail",ab,message)
                print("success")
                err = QMessageBox()
                err.setIcon(QMessageBox.Information)
                err.setText("Next 7 Days Prediction sent successful") 
                err.setWindowTitle("Success")
                err.setStandardButtons(QMessageBox.Ok)
                retval = err.exec_()
                nm = self.name_line.setText("")
                ab = self.email_line.setText("")
                server.quit()
                
            except Exception as e:
                print("error",e)
         
class Weather2(QDialog):
    
    def __init__(self):
        super(Weather2,self).__init__()
        loadUi("weather2.ui",self)
        self.setWindowTitle('Weather Forecast')
        self.searchee.clicked.connect(self.search)
        self.backbtn.clicked.connect(self.back)

    def back(self):
        welcome.show()
        w2.close()

    def search(self):
        
        try:
            city = self.locationbox.text()
            geolocator = Nominatim(user_agent="geoapiExercises")
            location = geolocator.geocode(city)
            obj = TimezoneFinder()
            result = obj.timezone_at(lng=location.longitude, lat=location.latitude)
            home = pytz.timezone(result)
            local_time = datetime.now(home)
            current_time = local_time.strftime("%I:%M %p")

            # Weather API
            api = (
                "https://api.openweathermap.org/data/2.5/weather?q="
                + city
                + "&appid=a0436779bfc4457741c32fb931a75148"
            )

            json_data = requests.get(api).json()
            condition = str(json_data["weather"][0]["main"])
            tempt = str(int(json_data["main"]["temp"] - 273.15))
            feels_like = str(int(json_data["main"]["feels_like"] - 273.15))
            press = str(json_data["main"]["pressure"])
            humid = str(json_data["main"]["humidity"])
            wind_1 = str(json_data["wind"]["speed"])
            self.texter(condition,tempt,feels_like,press,humid,wind_1,current_time)
        
        except Exception as e:
            print(e)
           
    def texter(self,condition,tempt,feels_like,press,humid,wind_1,current_time):

        self.timelb.setText(current_time)
        self.temlb.setText(tempt + "°")
        self.smokelb.setText(condition+" | "+" FEELS LIKE "+feels_like+"°")
        self.windlb.setText(wind_1)
        self.humiditylb.setText(humid)
        self.preslb.setText(press)

#main
app =QApplication(sys.argv)

#objects
welcome = Mainwindow()
w2 = Weather2()

#mainscreen 
welcome.setFixedHeight(600)
welcome.setFixedWidth(900)
welcome.show()

app.exec()