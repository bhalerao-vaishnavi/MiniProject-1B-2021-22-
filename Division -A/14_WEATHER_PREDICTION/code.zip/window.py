from tkinter import *

def btn_clicked():
    
    window.destroy()



window = Tk(homeframe)
window.geometry("900x600")

homeframe = Frame()
homeframe.place(x=0,y=0,width=900,height=600)

window.configure(bg = "#efefef")
canvas = Canvas(
    homeframe,
    bg = "#efefef",
    height = 600,
    width = 900,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge")
canvas.place(x = 0, y = 0)

background_img = PhotoImage(file = f"background.png")
background = canvas.create_image(
    450.0, 300.0,
    image=background_img)

entry0_img = PhotoImage(file = f"img_textBox0.png")
entry0_bg = canvas.create_image(
    267.0, 379.5,
    image = entry0_img)

entry0 = Entry(
    homeframe,
    bd = 0,
    bg = "#d6d3d3",
    highlightthickness = 0)

entry0.place(
    x = 127.0, y = 358,
    width = 280.0,
    height = 41)

entry1_img = PhotoImage(file = f"img_textBox1.png")
entry1_bg = canvas.create_image(
    267.0, 287.5,
    image = entry1_img)

entry1 = Entry(
    homeframe,
    bd = 0,
    bg = "#d6d3d3",
    highlightthickness = 0)

entry1.place(
    x = 127.0, y = 266,
    width = 280.0,
    height = 41)

img0 = PhotoImage(file = f"img0.png")
b0 = Button(
    homeframe.master,
    image = img0,
    borderwidth = 0,
    highlightthickness = 0,
    command = btn_clicked,
    relief = "flat")

b0.place(
    x = 199, y = 442,
    width = 126,
    height = 38)

img1 = PhotoImage(file = f"img1.png")
b1 = Button(
    homeframe.master,
    image = img1,
    borderwidth = 0,
    highlightthickness = 0,
    command = btn_clicked,
    relief = "flat")

b1.place(
    x = 546, y = 247,
    width = 225,
    height = 60)

img2 = PhotoImage(file = f"img2.png")
b2 = Button(
    homeframe.master,
    image = img2,
    borderwidth = 0,
    highlightthickness = 0,
    command = btn_clicked,
    relief = "flat")

b2.place(
    x = 575, y = 335,
    width = 167,
    height = 60)

# window.resizable(False, False)
# window.mainloop()
