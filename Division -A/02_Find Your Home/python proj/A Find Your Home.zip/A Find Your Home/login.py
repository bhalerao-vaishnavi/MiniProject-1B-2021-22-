'''
Author - DAMM Group
App Name - Find Your Home
Working - For finding suitable flats, houses, Bungalows, etc for purchasing
'''
#Dividing the code into three parts
'''
:LOGIN/REGISTER PAGE
:MAIN SELL PAGE
:MAIN BUY PAGE
:LOGOUT PAGE
'''

#Importing all the modules
from cProfile import label
import email
from struct import pack
import tkinter as tk
import turtle
from unicodedata import name
from PIL import Image,ImageTk
import PIL.Image
from tkinter import *
from tkinter import font
from turtle import back, bgpic, color
from tkinter import *
import tkinter.messagebox
import sqlite3
from tkinter import messagebox
import random
import smtplib

#First designing the first window of app
# i.e setting background images and dimensions for the window we will work in
root = Tk()
root.geometry("1024x682+0+0")
root.config(bg="white")
root.resizable(0,0)

bg = PIL.Image.open("bgimage.jpg")
photo = ImageTk.PhotoImage(bg)
label = Label(image=photo).place(x=0, y=0,relwidth=1,relheight=1)

left = PIL.Image.open("your.jpg")
left = ImageTk.PhotoImage(left)
label = Label(image=left).place(x=80, y=100,width=450,height=500)

right_frame=Frame (root,bg="white")
right_frame.place(x=480, y=100, width=500, height=500)

#creating users database

# conn = sqlite3.connect('users.db')

# #create cursor
# c = conn.cursor()

# #Creating tablwe
# '''
# c.execute("""CREATE TABLE users (
#     first_name text,
#     last_name text,
#     email_id text,
#     mobile_no integer,
#     paaswd text
# )""")
# '''
# # commit changes
# conn.commit()

# # close connection
# conn.close()

#creating properties database

# conn = sqlite3.connect('users.db')

# #create cursor
# c = conn.cursor()

# c.execute("""CREATE TABLE user_properties (
#     OwnerN text,
#     mobile_no integer,
#     emailid text,
#     propertytype text,
#     bhks text,
#     superarea integer,
#     carpetarea integer,
#     status text,
#     rpoption text,
#     facilities text,
#     state text,
#     cityvill text,
#     landmark text,
#     address text,
#     price integer,
#     unit text
# )""")


# commit changes
# conn.commit()

# close connection
# conn.close()


#command for the login button

def validate():

    phoneno1 = phoneno.get()
    passw_entry = entry_2.get()
    if phoneno=='' or passw_entry=='':
        messagebox.showerror('Error', 'Feilds cannot be empty!')
    else:
      #open database
      conn = sqlite3.connect('users.db')
      #select query
      cursor = conn.execute('SELECT * from users where mobile_no="%s" and paaswd="%s"'%(phoneno1,passw_entry))
      #fetch data 
      if cursor.fetchone():
       messagebox.showinfo('Login Status', 'Logged in Successfully!')
       root.destroy()
       import home
       home()
      else:
       messagebox.showerror('Login Status', 'invalid username or password')


def register():
    root.destroy()
    reg=Tk()
    reg.geometry("1024x682+0+0")
    reg.config(bg="white")
    reg.resizable(0,0)
    bg = PIL.Image.open("bgimage.jpg")
    photo = ImageTk.PhotoImage(bg)
    label = Label(image=photo).place(x=0, y=0,relwidth=1,relheight=1)
    left = PIL.Image.open("your.jpg")
    left = ImageTk.PhotoImage(left)
    label = Label(image=left).place(x=80, y=100,width=450,height=500)
    right_frame=Frame (reg,bg="white")
    right_frame.place(x=480, y=100, width=500, height=500)
    def regist():
        name = entry_1.get()
        last = entry_2.get()
        mobile = entry_4.get()
        password = entry_5.get()
        check_counter=0
        warn = ""
        if name == "":
            warn = "Name can't be empty"
        else:
            check_counter += 1
        if last == "":
            warn = "Last Name can't be empty"
        else:
            check_counter += 1

        if mobile  == "":
            warn = "Contact can't be empty"
        else:
            check_counter += 1
        if password == "":
            warn = "Feilds cannot be empty"
        else:
            check_counter += 1
        
        if check_counter == 4:
            try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO users VALUES (:first_name, :last_name,  :mobile_no, :paaswd)", {
                            'first_name': name,
                            'last_name': last,
                            'mobile_no': mobile,
                            'paaswd': password
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'Registered Successfully')
                reg.destroy()
                import home
                home()
            except Exception as ep:
                messagebox.showerror('', ep) 
        else:
            messagebox.showerror('Error', warn)
    def close():
        reg.destroy()
    label_0 = Label(right_frame, text="Register here..", font=("Courier Italic", 20, font.ITALIC, UNDERLINE))
    label_0.place(x=90, y=53)

    label_1 = Label(right_frame, text="First Name:", width=23, font=("bold", 13),fg="black")
    label_1.place(x=25, y=130)
    entry_1 = Entry(right_frame, font = ('calibre',10,'normal'),bg="#A9A9A9")
    entry_1.place(x=240, y=135)

    label_2 = Label(right_frame, text="Last Name:", width=23, font=("bold", 13),fg="black")
    label_2.place(x=25, y=180)
    entry_2 = Entry(right_frame, font = ('calibre',10,'normal'),bg="#A9A9A9")
    entry_2.place(x=240, y=185)

    label_4 = Label(right_frame, text="Enter Mobile:", width=23, font=("bold", 13),fg="black")
    label_4.place(x=25, y=230)
    entry_4 = Entry(right_frame, font = ('calibre',10,'normal'),bg="#A9A9A9")
    entry_4.place(x=240, y=235)

    label_5 = Label(right_frame, text="Set Password:", width=23, font=("bold", 13),fg="black")
    label_5.place(x=25, y=280)
    entry_5 = Entry(right_frame, font = ('calibre',10,'normal'), show = '*', bg="#A9A9A9")
    entry_5.place(x=240, y=285)

    Button(right_frame, text='Submit', width=20, bg='green', fg='white', command=regist).place(x=300, y=450)
    Button(right_frame, text='Close', width=20, bg='green', fg='white', command=close).place(x=50, y=450)
    reg.mainloop()

# def ottp():
#     root.destroy()
#     otpp=Tk()

#     rand=random.randint(1,999999)

#     msg=f"Your One Time Password(OTP) is {rand}"

#     def sms_send(a,msg):
#         s = smtplib.SMTP("smtp.gmail.com" , 587)  # 587 is a port number 
#         s.starttls()
#         s.login("darpanmhatre25@gmail.com" , "Etherzoro")
#         s.sendmail("sender_email" , a , msg)
#         s.quit


#     def send():
#         a=num.get()
#         if(a==""):
#             messagebox.showerror("Error","Enter Your Email")
#         else:
#             b=messagebox.askyesno("Info",f"Your Email is {a}")
#             if(b==True):
#                 sms_send(a,msg)
#             else:
#                 num.set("")

#     def check():
#         c=otp.get()
#         if(c==""):
#             messagebox.showerror("Error","Enter OTP")
#         else:
#             if(str(rand)==c):
#                 d=messagebox.askokcancel("Info","Validation Successful proceed for registration")
#                 root.destroy()
#                 register()
#             else:
#                 messagebox.showerror("Error","Invalid OTP")
#                 num.set("")
#                 otp.set("")

#     otpp.geometry("500x500")
#     otpp.title("OTP-Checker")

#     num=StringVar()
#     otp=StringVar()

#     f1=Frame(otpp)
#     Label(f1,text="Verification",font="SegoeUI 30 bold",fg="purple").pack(padx=5,pady=10)
#     f1.pack(fill=BOTH)

#     f2=Frame(otpp)
#     Label(f2,text="Enter Your Email",font="SegoeUI 20 bold",fg="teal").pack(padx=5,pady=5)
#     e1=Entry(f2,textvariable=num,font="SegoeUI 14 bold",fg="black",bg="white",relief=SUNKEN,borderwidth=4,justify="center").pack(ipady=5)
#     f2.pack(fill=BOTH,padx=5,pady=10)

#     f3=Frame(otpp)
#     Label(f3,text="Enter OTP",font="SegoeUI 20 bold",fg="teal").pack(padx=5,pady=5)
#     e2=Entry(f3,textvariable=otp,font="SegoeUI 14 bold",fg="black",bg="white",relief=SUNKEN,borderwidth=5,justify="center").pack(ipady=5)
#     f3.pack(fill=BOTH,padx=5,pady=10)

#     f4=Frame(otpp)
#     Button(f4,text="Send OTP",command=send,font="SegoeUI 10 bold",fg="purple").pack(padx=20,pady=10,side=LEFT)
#     Button(f4,text="Check OTP",command=check,font="SegoeUI 10 bold",fg="purple").pack(padx=40,pady=10,side=LEFT)
#     f4.pack()

# Now setting widgets(labels, textboxes, and buttons) for login

label_0 = Label(right_frame,text="Already a User!...Log in!", font=("Courier Italic", 20, font.ITALIC, UNDERLINE))
label_0.place(x=90, y=53)

label_1 = Label(right_frame, text="Registered Phone Number:", width=23, font=("bold", 13),fg="Black")
label_1.place(x=30, y=130)

phoneno= Entry(right_frame, font = ('calibre',10,'normal'),bg="#A9A9A9")
phoneno.place(x=240, y=132)

label_2 = Label(right_frame, text="Password:", width=23, font=("bold", 13),fg="black")
label_2.place(x=30, y=180)

entry_2= Entry(right_frame, font = ('calibre',10,'normal'), show = '*', bg="#A9A9A9")
entry_2.place(x=240, y=182)

Button(right_frame, text='Log In', width=20, bg='green', fg='white', command=validate).place(x=180, y=250)

label_3 = Label(right_frame, text="New User? Please Resgister!", width=30, font=('courier', 15, 'bold'),bg="white")
label_3.place(x=90, y=350)

Button(right_frame, text='Register', width=20, bg='Blue', fg='white', command=register).place(x=180, y=400)
root.mainloop()











    
      