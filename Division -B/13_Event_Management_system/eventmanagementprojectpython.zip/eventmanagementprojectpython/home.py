from tkinter import *
from tkinter import ttk
from tkinter import Frame
from tkinter import Label
from PIL import Image,ImageTk
from tkinter import messagebox
import webbrowser
from tkintermapview import TkinterMapView
import random
import re
import pymysql\

def homepage():
    global event_root
    event_root = Tk()
    event_root.geometry("1200x645")
    event_root.minsize(200,100)
    event_root.title("Eventos")
    event_root.configure(bg="black")
    photo1=ImageTk.PhotoImage(file="images\\eventos1.png")
    pix1=Label(event_root,image=photo1)
    pix1.place(x=10,y=30)
    Home = Button(event_root, text = "Home",bg="light blue",fg="white",font=20).place(x=855,y=30)
    Admin = Button(event_root, text = "Admin",bg="light blue",fg="white",font=20,command=self.adminLogin).place(x=953,y=30)
    Login = Button(event_root, text = "Login",bg="light blue",fg="white",font=20,command=self.registerPage).place(x=1051,y=30)
    img= (Image.open("images\\btsfinal.jpeg"))
    resized_image= img.resize((1400,500), Image.Resampling.LANCZOS)
    photo2=ImageTk.PhotoImage(resized_image)
    pix2=Label(event_root,image=photo2)
    pix2.place(x=0,y=190)
    label1=Label(event_root,text="EVENT ORGANISER",font=20).place(x=570,y=300)
    label1=Label(event_root,text="CREATIVE & EXPERIENCED",font=100).place(x=530,y=350)
    label1=Label(event_root,text="WE ARE ONE OF THE BEST EVENT ORGANISERS",font=50).place(x=420,y=400)
    SIGNUP = Button(event_root, text = "SIGN UP",fg="Red",font=20).place(x=570,y=450)
    event_root.mainloop()
class Signup:
    def __init__(self, root):
        self.event_root_1 = root
        self.event_root_1.geometry("1280x645")
        self.event_root_1.minsize(200, 100)
        self.event_root_1.title("Register")
        self.homepage()

    def homepage(self):
        Frame_home = Frame(self.event_root_1, bg="IndianRed1")

        Frame_home.place(x=0, y=0, height=645, width=1280)
        self.photo1 = ImageTk.PhotoImage(file="images\\eventos1.png")
        pix1 = Label(Frame_home, image=self.photo1)
        pix1.place(x=10, y=30)
        Home = Button(Frame_home, text="Home", bg="light blue", fg="white", font=20).place(x=855, y=30)
        Admin = Button(Frame_home, text="Admin", bg="light blue", fg="white", font=20,command=self.adminLogin).place(x=953, y=30)
        Login = Button(Frame_home, text="Login", bg="light blue", fg="white", font=20,
                           command=self.loginform).place(x=1051, y=30)
        self.img = (Image.open("images\\btsfinal.jpeg"))
        resized_image = self.img.resize((1400, 500), Image.Resampling.LANCZOS)
        self.photo2 = ImageTk.PhotoImage(resized_image)
        pix2 = Label(Frame_home, image=self.photo2)
        pix2.place(x=0, y=190)
        label1 = Label(Frame_home, text="EVENT ORGANISER", font=20).place(x=570, y=300)
        label1 = Label(Frame_home, text="CREATIVE & EXPERIENCED", font=100).place(x=530, y=350)
        label1 = Label(Frame_home, text="WE ARE ONE OF THE BEST EVENT ORGANISERS", font=50).place(x=420, y=400)
        SIGNUP = Button(Frame_home, text="SIGN UP", fg="Red", font=20,command=self.Register).place(x=570, y=450)

    def loginform(self):
        Frame_login = Frame(self.event_root_1, bg="white")

        Frame_login.place(x=0, y=0, height=700, width=1366)

        #self.img = ImageTk.PhotoImage(file="background-2.jpg")

        #img = Label(Frame_login, image=self.img).place(x=0, y=0, width=1366, height=700)

        frame_input = Frame(self.event_root_1, bg='white')

        frame_input.place(x=320, y=130, height=450, width=350)

        label1 = Label(frame_input, text="Login Here", font=('impact', 32, 'bold'),

                       fg="black", bg='white')

        label1.place(x=75, y=40)

        label2 = Label(frame_input, text="Username", font=("Goudy old style", 20, "bold"),

                       fg='orangered', bg='white')

        label2.place(x=30, y=95)

        self.email_txt = Entry(frame_input, font=("times new roman", 15, "bold"),

                               bg='lightgray')

        self.email_txt.place(x=30, y=145, width=270, height=35)

        label3 = Label(frame_input, text="Password", font=("Goudy old style", 20, "bold"),

                       fg='orangered', bg='white')

        label3.place(x=30, y=195)

        self.password = Entry(frame_input, font=("times new roman", 15, "bold"),

                              bg='lightgray',show="*")

        self.password.place(x=30, y=245, width=270, height=35)

        btn2 = Button(frame_input, text="Login",  cursor="hand2", command=self.login,

                      font=("times new roman", 15), fg="white", bg="orangered",

                      bd=0, width=15, height=1)

        btn2.place(x=90, y=340)

        btn3 = Button(frame_input, command=self.Register, text="Not Registered?register"

                      , cursor="hand2", font=("calibri", 10), bg='white', fg="black", bd=0)

        btn3.place(x=110, y=390)

        btn4 = Button(frame_input, command=self.homepage,

                      text="Home", cursor="hand2",

                      font=("calibri", 10), bg='red', fg="black", bd=0)

        btn4.place(x=110, y=420)

    def login(self):

        if self.email_txt.get() == "" or self.password.get() == "":

            messagebox.showerror("Error", "All fields are required", parent=self.event_root_1)

        else:

            try:

                con = pymysql.connect(host='localhost', user='root', password='',

                                      database='EventManagementdb')

                cur = con.cursor()

                cur.execute('select * from register where emailid=%s and password=%s'

                            , (self.email_txt.get(), self.password.get()))

                row = cur.fetchone()

                if row == None:

                    messagebox.showerror('Error', 'Invalid Username And Password'

                                         , parent=self.event_root_1)

                    self.loginclear()

                    self.email_txt.focus()

                else:

                    self.appscreen()

                    con.close()

            except Exception as es:

                messagebox.showerror('Error', f'Error Due to : {str(es)}'

                                     , parent=self.event_root_1)

    def Register(self):
        Frame_login1 = Frame(self.event_root_1, bg="white")

        Frame_login1.place(x=0, y=0, height=700, width=1366)

        #self.img = ImageTk.PhotoImage(file="background-2.jpg")

        #img = Label(Frame_login1, image=self.img).place(x=0, y=0, width=1366, height=700)

        frame_input2 = Frame(self.event_root_1, bg='white')

        frame_input2.place(x=320, y=130, height=450, width=630)

        label1 = Label(frame_input2, text="Register Here", font=('impact', 32, 'bold'),

                   fg="black", bg='white')

        label1.place(x=45, y=20)

        label2 = Label(frame_input2, text="Username", font=("Goudy old style", 20, "bold"),

                   fg='orangered', bg='white')

        label2.place(x=30, y=95)

        self.entry = Entry(frame_input2, font=("times new roman", 15, "bold"),

                       bg='lightgray')

        self.entry.place(x=30, y=145, width=270, height=35)

        label3 = Label(frame_input2, text="Password", font=("Goudy old style", 20, "bold"),

                   fg='orangered', bg='white')

        label3.place(x=30, y=195)

        self.entry2 = Entry(frame_input2, font=("times new roman", 15, "bold"),

                        bg='lightgray',show="*")

        self.entry2.place(x=30, y=245, width=270, height=35)

        label4 = Label(frame_input2, text="Email-id", font=("Goudy old style", 20, "bold"),

                   fg='orangered', bg='white')

        label4.place(x=330, y=95)

        self.entry3 = Entry(frame_input2, font=("times new roman", 15, "bold"),

                        bg='lightgray')

        self.entry3.place(x=330, y=145, width=270, height=35)

        label5 = Label(frame_input2, text="Confirm Password",

                   font=("Goudy old style", 20, "bold"), fg='orangered', bg='white')

        label5.place(x=330, y=195)

        self.entry4 = Entry(frame_input2, font=("times new roman", 15, "bold"),

                        bg='lightgray',show="*")

        self.entry4.place(x=330, y=245, width=270, height=35)

        btn2 = Button(frame_input2, text="Register", command=self.register

                  , cursor="hand2", font=("times new roman", 15), fg="white",

                  bg="orangered", bd=0, width=15, height=1)

        btn2.place(x=90, y=340)

        btn3 = Button(frame_input2, command=self.loginform,

                  text="Already Registered?Login", cursor="hand2",

                  font=("calibri", 10), bg='white', fg="black", bd=0)

        btn3.place(x=110, y=390)

        btn4 = Button(frame_input2, command=self.homepage,

                      text="Home", cursor="hand2",

                      font=("calibri", 10), bg='red', fg="black", bd=0)

        btn4.place(x=110, y=420)

    def register(self):

        if self.entry.get() == "" or self.entry2.get() == "" or self.entry3.get() == "" or self.entry4.get() == "":

            messagebox.showerror("Error", "All Fields Are Required", parent=self.event_root_1)

        elif self.entry2.get() != self.entry4.get():

            messagebox.showerror("Error", "Password and Confirm Password Should Be Same"

                                 , parent=self.event_root_1)

        else:

            try:

                con = pymysql.connect(host="localhost", user="root", password="",

                                      database="EventManagementdb")

                cur = con.cursor()

                cur.execute("select * from register where emailid=%s"

                            , self.entry3.get())

                row = cur.fetchone()

                if row != None:

                    messagebox.showerror("Error"

                                         , "User already Exist,Please try with another Email"

                                         , parent=self.event_root_1)

                    self.regclear()

                    self.entry.focus()

                else:

                    cur.execute("insert into register values(%s,%s,%s,%s)"

                                , (self.entry.get(), self.entry3.get(),

                                   self.entry2.get(),

                                   self.entry4.get()))

                    con.commit()

                    con.close()

                    messagebox.showinfo("Success", "Register Succesfull"

                                        , parent=self.event_root_1)

                    self.regclear()

            except Exception as es:

                messagebox.showerror("Error", f"Error due to:{str(es)}"

                                     , parent=self.event_root_1)

    def appscreen(self):
        s = ttk.Style()
        s.configure('My.TFrame', background='black')

        # Create Panedwindow
        panedwindow = ttk.Panedwindow(root, orient=HORIZONTAL)
        panedwindow.pack(fill=BOTH, expand=True)

        # Create Frams
        fram1 = ttk.Frame(panedwindow,style='My.TFrame' ,width=100, height=300, relief=SUNKEN)
        fram2 = ttk.Frame(panedwindow, width=400, height=400,relief=SUNKEN)
        panedwindow.add(fram1, weight=1)
        panedwindow.add(fram2, weight=4)
        user = Label(fram1, text="U-SER", font=("Goudy old style", 20, "bold"),

                       fg='orangered')

        user.place(x=100, y=30)
        btn1 = Button(fram1, command=self.homepage,

                      text="HOME", cursor="hand2",

                      font=("calibri", 20),  fg="black", bd=0)

        btn1.place(x=30, y=190)
        btn2 = Button(fram1, command=self.BookEvent,

                      text="BOOK EVENTS", cursor="hand2",

                      font=("calibri", 20), fg="black", bd=0)

        btn2.place(x=30, y=270)
        btn3 = Button(fram1, text="ARRANGE EVENTS", command=self.myevent,cursor="hand2",

                      font=("calibri", 20), fg="black", bd=0)

        btn3.place(x=30, y=350)

        self.img1 = (Image.open("images\\userpage.jpg"))
        resized_image2 = self.img1.resize((1385, 700), Image.Resampling.LANCZOS)
        self.photo3= ImageTk.PhotoImage(resized_image2)
        pix5 = Label(fram2, image=self.photo3)
        pix5.place(x=0, y=0)
        colors = ["dark turquoise","deep pink","DarkGoldenrod1", "magenta2","IndianRed1","VioletRed1"]
        def color_changer():
            fg = random.choice(colors)
            changetext.config(fg=fg)
            changetext.after(400, color_changer)
            changeLabels=["OUR HEADQUATERS ARE IN AGRA","OUR HEADQUATERS ARE IN DELHI","OUR HEADQUATERS ARE IN KERALA","OUR HEADQUATERS ARE IN MUMBAI","OUR HEADQUATERS ARE IN BANGLORE","OUR HEADQUATERS ARE IN RAJASTHAN"]
            text = random.choice(changeLabels)
            changetext.config(text=text)
           # changetext.place(x=550,y=350)
        changetext = Label(fram2, font=("Goudy old style", 30, "bold"), fg='green')
        changetext.place(x=70, y=350)
        color_changer()


    def BookEvent(self):
        Frame_BookEvent = Frame(self.event_root_1, bg="white")
        Frame_BookEvent.place(x=0, y=0, height=700, width=1366)
        B = Label(Frame_BookEvent, text="B", font=("Goudy old style", 20, "bold"),fg='orangered', bg="light salmon")
        B.place(x=500, y=10)
        O = Label(Frame_BookEvent, text="O", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        O.place(x=530, y=10)
        O = Label(Frame_BookEvent, text="O", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        O.place(x=560, y=10)
        K = Label(Frame_BookEvent, text="K", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        K.place(x=590, y=10)
        E = Label(Frame_BookEvent, text="E", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        E.place(x=620, y=10)
        V = Label(Frame_BookEvent, text="V", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        V.place(x=650, y=10)
        E = Label(Frame_BookEvent, text="E", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        E.place(x=680, y=10)
        N = Label(Frame_BookEvent, text="N", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        N.place(x=710, y=10)
        T = Label(Frame_BookEvent, text="T", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        T.place(x=740, y=10)
        self.imgholi = (Image.open("images\\holi.jpeg"))
        resized_imageholi = self.imgholi.resize((400, 290), Image.Resampling.LANCZOS)
        self.photoholi = ImageTk.PhotoImage(resized_imageholi)
        pixholi = Label(Frame_BookEvent, image=self.photoholi)
        pixholi.place(x=7, y=70)
        self.imgholi2 = (Image.open("images\\holi2.jpeg"))
        resized_imageholi2 = self.imgholi2.resize((500, 300), Image.Resampling.LANCZOS)
        self.photoholi2 = ImageTk.PhotoImage(resized_imageholi2)
        pixholi2 = Label(Frame_BookEvent, image=self.photoholi2)
        pixholi2.place(x=450, y=70)

        btnmap1 = Button(Frame_BookEvent, text="map", command=self.map, cursor="hand2", font=("calibri", 20), fg="black",
                        bd=0)
        btnmap1.place(x=450, y=400)
        holilabel5 = Label(Frame_BookEvent, text="Palolem Beach", font=("Goudy old style", 20, "bold"),
                          fg='blue', cursor="hand2")
        holilabel5.place(x=450, y=475)
        holilabel6 = Label(Frame_BookEvent, text="Holi in Goa", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel6.place(x=450, y=520)
        holilabel7 = Label(Frame_BookEvent, text="Sat 30 April 2022 At 11:00 AM", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel7.place(x=450, y=550)
        holilabel8 = Label(Frame_BookEvent, text="₹ 1500", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel8.place(x=450, y=580)
        btnbook1 = Button(Frame_BookEvent, text="Book Now", command=self.Payment, cursor="hand2", font=("calibri", 20),
                         fg="white", bg="dark orange",
                         bd=0)
        btnbook1.place(x=450, y=610)

        self.imgkailash = (Image.open("images\\kailash.jpeg"))
        resized_imagekailash = self.imgkailash.resize((300, 300), Image.Resampling.LANCZOS)
        self.photokailash = ImageTk.PhotoImage(resized_imagekailash)
        pixkailash = Label(Frame_BookEvent, image=self.photokailash)
        pixkailash.place(x=980, y=70)

        btnmap2 = Button(Frame_BookEvent, text="map", command=self.map, cursor="hand2", font=("calibri", 20),
                         fg="black",
                         bd=0)
        btnmap2.place(x=980, y=400)
        holilabel5 = Label(Frame_BookEvent, text="Brabourne Stadium", font=("Goudy old style", 20, "bold"),
                           fg='blue', cursor="hand2")
        holilabel5.place(x=980, y=475)
        holilabel6 = Label(Frame_BookEvent, text="Musical Evening", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel6.place(x=980, y=520)
        holilabel7 = Label(Frame_BookEvent, text="Fri 6 May 2022 At 6:00 PM", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel7.place(x=980, y=550)
        holilabel8 = Label(Frame_BookEvent, text="₹ 1500", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel8.place(x=980, y=580)
        btnbook2 = Button(Frame_BookEvent, text="Book Now", command=self.Payment, cursor="hand2", font=("calibri", 20),
                          fg="white", bg="dark orange",
                          bd=0)
        btnbook2.place(x=980, y=610)

        holilabel = Label(Frame_BookEvent, text="Rude Lounge,Powai:mumbai", font=("Goudy old style", 20, "bold"),
                          fg='blue', cursor="hand2")
        holilabel.place(x=7, y=475)
        btnmap = Button(Frame_BookEvent, text="map",command=self.map, cursor="hand2",font=("calibri", 20), fg="black", bd=0)
        btnmap.place(x=7, y=400)

        holilabel2 = Label(Frame_BookEvent, text="Holi Bash", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel2.place(x=10, y=520)
        holilabel3 = Label(Frame_BookEvent, text="Sat 30 April 2022 At 11:00 AM", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel3.place(x=10, y=550)
        holilabel4 = Label(Frame_BookEvent, text="₹ 900", font=("Goudy old style", 10, "bold"),
                           fg='black', cursor="hand2")
        holilabel4.place(x=10, y=580)
        btnbook = Button(Frame_BookEvent, text="Book Now", command=self.Payment, cursor="hand2", font=("calibri", 20), fg="white", bg="dark orange",
                        bd=0)
        btnbook.place(x=10, y=610)
        Back = Button(Frame_BookEvent, command=self.appscreen,text="BACK", cursor="hand2",
                      font=("calibri", 20), bg='red', fg="white", bd=0)
        Back.place(x=0, y=0)

        myscrollbar = Scrollbar(Frame_BookEvent)
        myscrollbar.pack(side="right", fill="y")

    def Payment(self):
        Frame_payment = Frame(self.event_root_1, bg="SpringGreen2")
        Frame_payment.place(x=0, y=0, height=700, width=1366)
        FramePayment_input2 = Frame(self.event_root_1, bg='white')
        FramePayment_input2.place(x=40, y=10, height=650, width=1200)

        Billing = Label(FramePayment_input2, text=" BILLING ADDRESS", font=('impact', 20, 'bold'),
                    fg="black", bg='white')
        Billing.place(x=45, y=20)
        Full_name = Label(FramePayment_input2, text="Full Name:", font=("Goudy old style", 20, "bold"),
                    fg='black', bg='white')
        Full_name.place(x=45, y=60)
        self.Full_name = Entry(FramePayment_input2, font=("times new roman", 15, "bold"),
                    bg='white')

        self.Full_name.place(x=45, y=100, width=300, height=35)
        Email = Label(FramePayment_input2, text="Email:", font=("Goudy old style", 20, "bold"),

                       fg='black', bg='white')

        Email.place(x=45, y=150)

        self.Email = Entry(FramePayment_input2, font=("times new roman", 15, "bold"),
                        bg='white')

        self.Email.place(x=45, y=190, width=300, height=35)

        Address = Label(FramePayment_input2, text="Address:", font=("Goudy old style", 20, "bold"),fg='black', bg='white')
        Address.place(x=45, y=230)

        self.Address = Entry(FramePayment_input2, font=("times new roman", 15, "bold"),bg='white')

        self.Address.place(x=45, y=270, width=270, height=35)

        City = Label(FramePayment_input2, text="City",font=("Goudy old style", 20, "bold"),
                       fg='black', bg='white')
        City.place(x=45, y=320)

        self.City = Entry(FramePayment_input2, font=("times new roman", 15, "bold"),bg='white')
        self.City.place(x=45, y=360, width=300, height=35)

        State = Label(FramePayment_input2, text="State", font=("Goudy old style", 20, "bold"),
                     fg='black', bg='white')
        State.place(x=45, y=400)

        self.State = Entry(FramePayment_input2, font=("times new roman", 15, "bold"), bg='white')
        self.State.place(x=45, y=450, width=300, height=35)


        PAYMENT = Label(FramePayment_input2, text="PAYMENT", font=('impact', 20, 'bold'),
                    fg="black", bg='white')
        PAYMENT.place(x=700, y=20)

        Cards = Label(FramePayment_input2, text="Cards Accepted :", font=("Goudy old style", 20, "bold"),
                      fg='black', bg='white')
        Cards.place(x=700, y=60)
        self.Cards = (Image.open("images\\Cards.jpeg"))
        resized_imageCards = self.Cards.resize((300, 50), Image.Resampling.LANCZOS)
        self.Cards = ImageTk.PhotoImage(resized_imageCards)
        pixCards = Label(FramePayment_input2, image=self.Cards)
        pixCards.place(x=700, y=100)
        NameCard = Label(FramePayment_input2, text="Name On Card:", font=("Goudy old style", 20, "bold"),
                     fg='black', bg='white')
        NameCard.place(x=700, y=180)
        self.NameCard = Entry(FramePayment_input2, font=("times new roman", 15, "bold"), bg='white')
        self.NameCard.place(x=700, y=230, width=300, height=35)
        CardNo = Label(FramePayment_input2, text="Credit Card Number:", font=("Goudy old style", 20, "bold"),
                         fg='black', bg='white')
        CardNo.place(x=700, y=270)
        self.CardNo = Entry(FramePayment_input2, font=("times new roman", 15, "bold"), bg='white')
        self.CardNo.place(x=700, y=300, width=300, height=35)
        Exp = Label(FramePayment_input2, text="Exp Month:", font=("Goudy old style", 20, "bold"),
                       fg='black', bg='white')
        Exp.place(x=700, y=350)
        self.Exp = Entry(FramePayment_input2, font=("times new roman", 15, "bold"), bg='white')
        self.Exp.place(x=700, y=390, width=300, height=35)
        Zip = Label(FramePayment_input2, text="Zip Code:", font=("Goudy old style", 20, "bold"),
                    fg='black', bg='white')
        Zip.place(x=700, y=430)
        self.Zip = Entry(FramePayment_input2, font=("times new roman", 15, "bold"), bg='white')
        self.Zip.place(x=700, y=470, width=270, height=35)
        Expyear = Label(FramePayment_input2, text="Exp Year:", font=("Goudy old style", 20, "bold"),
                    fg='black', bg='white')
        Expyear.place(x=45, y=490)
        self.Expyear = Entry(FramePayment_input2, font=("times new roman", 15, "bold"), bg='white')
        self.Expyear.place(x=45, y=520, width=270, height=35)
        CVV = Label(FramePayment_input2, text="CVV:", font=("Goudy old style", 20, "bold"),
                        fg='black', bg='white')
        CVV.place(x=45, y=580)
        self.CVV = Entry(FramePayment_input2, font=("times new roman", 15, "bold"), bg='white')
        self.CVV.place(x=150, y=580, width=270, height=35)

        chkout = Button(FramePayment_input2, text="Proceed To Checkout", command=self.payment,cursor="hand2",
                     font=("times new roman", 15), fg="white",bg="SpringGreen2", bd=0, width=20, height=1)
        chkout.place(x=700, y=600)
        Back1 = Button(FramePayment_input2, command=self.appscreen,text="Home", cursor="hand2",
                      font=("calibri", 10), bg='red', fg="white", bd=0)
        Back1.place(x=45, y=610)

    def payment(self):

        if self.Full_name.get() == "" or self.Email.get() == "" or self.Address.get() == "" or self.City.get() == "" or self.State.get() =="" or self.Expyear.get() =="" or self.CVV.get() =="" or self.NameCard.get() =="" or self.CardNo.get() =="" or self.Exp.get() =="" or self.Zip.get() ==""  :

            messagebox.showerror("Error", "All Fields Are Required", parent=self.event_root_1)

        else:

            try:

                con = pymysql.connect(host="localhost", user="root", password="",
                                      database="EventManagementdb")

                cur = con.cursor()
                cur.execute("insert into Payment values(%s,%s,%s,%s,%s,%s,%s)"
                                , (self.Full_name.get(), self.Address.get(),
                                   self.Email.get(),self.City.get(),self.State.get(),self.Zip.get(),
                                   self.NameCard.get()))

                con.commit()
                con.close()
                messagebox.showinfo("Success", "Event Booked"
                                        , parent=self.event_root_1)
            except Exception as es:
                messagebox.showerror("Error", f"Error due to:{str(es)}"
                                     , parent=self.event_root_1)
    def myevent(self):
        Frame_event = Frame(self.event_root_1, bg="SpringGreen2")
        Frame_event.place(x=0, y=0, height=700, width=1366)
        FrameEvent_input2 = Frame(self.event_root_1, bg='white')
        FrameEvent_input2.place(x=40, y=10, height=650, width=1200)
        E1 = Label(FrameEvent_input2, text="E", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        E1.place(x=620, y=10)
        V1= Label(FrameEvent_input2, text="V", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        V1.place(x=650, y=10)
        E2 = Label(FrameEvent_input2, text="E", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        E2.place(x=680, y=10)
        N1 = Label(FrameEvent_input2, text="N", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        N1.place(x=710, y=10)
        T1 = Label(FrameEvent_input2, text="T", font=("Goudy old style", 20, "bold"), fg='orangered', bg="light salmon")
        T1.place(x=740, y=10)
        Ename = Label(FrameEvent_input2, text="Event Name:", font=("Goudy old style", 20, "bold"),
                          fg='black', bg='white')
        Ename.place(x=45, y=60)
        self.Ename = Entry(FrameEvent_input2, font=("times new roman", 15, "bold"),
                               bg='white')

        self.Ename.place(x=45, y=100, width=600, height=35)
        Email1 = Label(FrameEvent_input2, text="Email:", font=("Goudy old style", 20, "bold"),

                      fg='black', bg='white')

        Email1.place(x=45, y=150)

        self.Email1 = Entry(FrameEvent_input2, font=("times new roman", 15, "bold"),
                           bg='white')

        self.Email1.place(x=45, y=190, width=600, height=35)

        Location = Label(FrameEvent_input2, text="Location:", font=("Goudy old style", 20, "bold"), fg='black',
                        bg='white')
        Location.place(x=45, y=230)

        self.Location = Entry(FrameEvent_input2, font=("times new roman", 15, "bold"), bg='white')

        self.Location.place(x=45, y=270, width=600, height=35)
        Contact = Label(FrameEvent_input2, text="Contact No.:", font=("Goudy old style", 20, "bold"), fg='black',
                         bg='white')
        Contact.place(x=45, y=320)

        self.Contact = Entry(FrameEvent_input2, font=("times new roman", 15, "bold"), bg='white')

        self.Contact.place(x=45, y=370, width=600, height=35)

        submit1= Button(FrameEvent_input2, text="Submit", command=self.event, cursor="hand2",
                        font=("times new roman", 15), fg="white", bg="SpringGreen2", bd=0, width=20, height=1)
        submit1.place(x=200, y=420)
        Back2 = Button(FrameEvent_input2, command=self.appscreen, text="Back", cursor="hand2",
                      font=("calibri", 20), bg='red', fg="black", bd=0)
        Back2.place(x=45, y=420)

    def event(self):

        if self.Ename.get() == "" or self.Email1.get() == "" or self.Location.get() == "" or self.Contact.get() == "":

            messagebox.showerror("Error", "All Fields Are Required", parent=self.event_root_1)

        else:

            try:

                con = pymysql.connect(host="localhost", user="root", password="",database="EventManagementdb")

                cur = con.cursor()

                cur.execute("insert into event values(%s,%s,%s,%s)", (self.Ename.get(), self.Email1.get(),
                                    self.Location.get(),self.Contact.get()))
                con.commit()

                con.close()

                messagebox.showinfo("Success", "Event Registered Succesfully!!,Our team will get back to you", parent=self.event_root_1)



            except Exception as es:

                messagebox.showerror("Error", f"Error due to:{str(es)}", parent=self.event_root_1)

    def adminLogin(self):
        Frame_LoginAdmin = Frame(self.event_root_1, bg="IndianRed1")
        Frame_LoginAdmin.place(x=0, y=0, height=700, width=1366)
        frame_Admininput = Frame(self.event_root_1, bg='RosyBrown1')
        frame_Admininput.place(x=500, y=130, height=400, width=350)
        self.imgadmin = (Image.open("images\\admin2.png"))
        resized_imageadmin = self.imgadmin.resize((200, 100), Image.Resampling.LANCZOS)
        self.photoadmin = ImageTk.PhotoImage(resized_imageadmin)
        pixadmin = Label(Frame_LoginAdmin, image=self.photoadmin)
        pixadmin.place(x=550, y=10)
        label1 = Label(frame_Admininput, text="Login Here", font=('impact', 25, 'bold'), fg="black", bg='RosyBrown1')
        label1.place(x=75, y=40)
        Username1 = Label(frame_Admininput, text="Username", font=("Goudy old style", 20, "bold"), fg='orangered',
                          bg='RosyBrown1')
        Username1.place(x=40, y=95)
        self.Username1 = Entry(frame_Admininput, font=("times new roman", 15, "bold"), bg='white')
        self.Username1.place(x=40, y=160, width=270, height=35)
        Adminpassword1 = Label(frame_Admininput, text="Password", font=("Goudy old style", 20, "bold"), fg='orangered',
                              bg='RosyBrown1')
        Adminpassword1.place(x=40, y=200)
        self.Adminpassword1 = Entry(frame_Admininput, font=("times new roman", 15, "bold"), bg='white')
        self.Adminpassword1.place(x=40, y=260, width=270, height=35)
        AdminLogin = Button(frame_Admininput, text="Login", cursor="hand2", command=self.admin,
                            font=("times new roman", 15), fg="white", bg="orangered", bd=0, width=10, height=1)
        AdminLogin.place(x=190, y=320)
        notadmin = Button(frame_Admininput, command=self.homepage,text="Not Admin?", cursor="hand2",
                      font=("times new roman", 15), bg='orangered', fg="white", bd=0, width=10, height=1)
        notadmin.place(x=40, y=320)

    def admin(self):
        if self.Username1.get() == "" or self.Adminpassword1.get() == "":
            messagebox.showerror("Error", "All fields are required", parent=self.event_root_1)

        else:

                try:

                    con = pymysql.connect(host='localhost', user='root', password='',
                                          database='EventManagementdb')

                    cur = con.cursor()

                    cur.execute('select * from Admin where Username1=%s and Adminpassword=%s'

                                , (self.Username1.get(), self.Adminpassword1.get()))

                    row = cur.fetchone()

                    if row == None:

                        messagebox.showerror('Error', 'Invalid Username And Password'

                                             , parent=self.event_root_1)

                        self.loginclearadmin()

                        self.Username1.focus()

                    else:
                        messagebox.showinfo("WELCOME"
                                            , parent=self.event_root_1)
                        con.close()

                except Exception as es:
                    messagebox.showerror('Error', f'Error Due to : {str(es)}'
                                         , parent=self.event_root_1)

    def map(self):
        Frame_new =Frame(self.event_root_1, bg="white")
        Frame_new.place(x=0, y=0, height=700, width=1366)
        map_widget = TkinterMapView(Frame_new, width=600, height=400, corner_radius=0)
        map_widget.pack(fill="both", expand=True)
        map_widget.set_address("Berlin Germany", marker=True)
        map_widget.set_zoom(20)

    def regclear(self):

        self.entry.delete(0, END)

        self.entry2.delete(0, END)

        self.entry3.delete(0, END)

        self.entry4.delete(0, END)

    def loginclear(self):

        self.email_txt.delete(0, END)

        self.password.delete(0, END)

    def regclearadmin(self):

        self.Username1.delete(0, END)

        self.Adminpassword1.delete(0, END)

    def loginclearadmin(self):

        self.Username1.delete(0, END)

        self.Adminpassword1.delete(0, END)



root=Tk()
ob=Signup(root)
root.mainloop()
